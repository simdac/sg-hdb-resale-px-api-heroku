import requests
import sys
import json
import sqlite3

db = sqlite3.connect("database/data.db")
cursor = db.cursor()

col_names = ['_id', 'month','town','flat_type','block','street_name','storey_range',
             'floor_area_sqm','flat_model','lease_commence_date','remaining_lease','resale_price']
types = ['int','text','text','text','text','text','text','numeric','text','text','text','numeric']
data_api = ["https://data.gov.sg/api/action/datastore_search?resource_id=adbbddd3-30e2-445f-a123-29bee150a6fe&limit=286450",
            "https://data.gov.sg/api/action/datastore_search?resource_id=8c00bf08-9124-479e-aeca-7cc411d884c4&limit=738052",
            "https://data.gov.sg/api/action/datastore_search?resource_id=83b2fc37-ce8c-4df4-968b-370fd818138b&limit=51203",
            "https://data.gov.sg/api/action/datastore_search?resource_id=1b702208-44bf-4829-b620-4615ee19b57c&limit=54806"]

if(len(sys.argv) < 2):
    id = 0
else:
    id = int(sys.argv[1])
data_url = data_api[id]

request = requests.get(data_url)
records = request.json()['result']['records']

for record in records:
    value_list = ""
    for i in range(len(col_names)):
        try:
            if(types[i] == "text"):
                if("'" in record[col_names[i]]):
                    value_list += '"'+str(record[col_names[i]])+'"' + ","
                else:
                    value_list += "'"+str(record[col_names[i]])+"'" + ","
            else:
                value_list += str(record[col_names[i]]) + ","
        except KeyError:
            print("NULL")
            value_list += "NULL,"
    value_list = value_list[:-1]
    insert_cmd = "INSERT INTO resale_flat_prices VALUES("+value_list+")"
    print(insert_cmd)
    cursor.execute(insert_cmd)
    db.commit()
