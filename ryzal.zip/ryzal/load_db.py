import sqlite3
import pandas as pd
import threading
# import ryzal.util.load_data_gov as load (if you run on PyCharm, import like this)
import util.load_data_gov as load # if run on terminal, import like this

# First : Need to get the metadata so that we cant create databases
# Second : load the dataset into that table
# Finally : Save the databases with the datasets saved
print("##############################################")
print("#        LOADING DEFAULT DATABASES           #")
print("##############################################")

ds_names = load.get_ds_list(keywords=['sale','flat'], inner_join=True)
default_ds_id = list(ds_names['id'])
db = sqlite3.connect("database/data.db")
cursor = db.cursor()

ds_create = list()
names = list()
for id in default_ds_id:
    name, describe = load.describe_ds(id)
    ds_create.append(describe)
    names.append(name)

    # Now we got the metadata, let's start making the tables:
print("##############################################")
print("#         GETTING TABLE METADATA             #")
print("##############################################")
lines = list()
col_names = list()
for description in ds_create:
    line = ""
    col_names_in_db = list()
    if(isinstance(description, pd.DataFrame)):
        for i in range(len(description['col_type'])-1):
            if(description['col_type'][i] == 'int4'):
                type = 'int'
            else:
                type = description['col_type'][i]
            name = description['col_name'][i]
            line += name + ' ' + type + ','
            col_names_in_db.append(name)
        line += description['col_name'][len(description)-1] + ' '
        line += description['col_type'][len(description)-1]
        col_names_in_db.append(description['col_name'][len(description)-1])

        lines.append(line)
        col_names.append(col_names_in_db)

sql_create_cmds = list()
# print(col_names)

for i in range(len(names)):
    name = names[i].replace("-","_")
    cmd = "CREATE TABLE " + name + "("
    cmd += lines[i]
    cmd += ")"
    sql_create_cmds.append(cmd)
# print(sql_create_cmds)

print("##############################################")
print("#              CREATING TABLES               #")
print("##############################################")

for i in range(len(sql_create_cmds)):
    print(sql_create_cmds[i])
    cursor.execute(sql_create_cmds[i])
    db.commit()

    # Done with creating, now inserting:
print("##############################################")
print("#         LOADING DATA INTO THE TABLES       #")
print("##############################################")

for i in range(len(names)):
    name = names[i].replace("-","_") # the table name
    id = default_ds_id[i] # dataset id
    ds = load.get_ds_by_index(id,limit=1000000) # the dataset
    db_name ,description = load.describe_ds(id)

    for x in range(len(ds)):
        values_list = ""
        cols = description['col_name']
        types = description['col_type']

        for y in range(len(cols)):
            col = cols[y]
            if(types[y] == "int4" or types[y]=="numeric"): # if the type is numeric
                if(str(ds[col][x]).isdigit()):
                    values_list += str(ds[col][x]) + ','
                else:
                    values_list += "NULL" + ','
            else:
                if('"' in str(ds[col][x])):
                    values_list += "'" + str(ds[col][x]) + "'" + ','
                else:
                    values_list += '"' + str(ds[col][x]) + '"' + ','
        values_list = values_list[:-1]

        command = "INSERT INTO " + name + " VALUES(" + values_list +")"
        print(command)
        cursor.execute(command)
        db.commit()


# Hi, guys, I have already created the .db sqlite file in database folder
# However, if for some reason that you lose the file
# Don't worry, just go to the terminal, cd into the 'ryzal' folder
# Then execute this script (load_db.py) then the .db file will appear in the
# database folder again. Good luck.